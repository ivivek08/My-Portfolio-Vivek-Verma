Video frame extraction (smaller archive)
Frame count: 239
Frame rate: source/native rate (24 fps)
Resolution: 1920x1080
Format: high-quality JPEG (lossy, visually high quality)
Files named sequentially frame_0001.jpg, frame_0002.jpg, etc.
